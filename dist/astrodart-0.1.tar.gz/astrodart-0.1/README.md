<p align="center">
  <img width = "600" src="./logo/AstroDART.png"/>
</p>

**Astro**nomical **DA**ta **R**eduction **T**ools
___


**AstroDART** is a collection of python tools for reduction of astronomical images taken with amateur or professional equipment. Allows for image alignment and combination for astrophotography uses and astrometry and photometry for more science oriented cases, like eclipsing binaries or exoplanet observations. 



